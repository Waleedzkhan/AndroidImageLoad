package com.io.example.imageloader

import java.util.Observable



class User: Observable() {







    /// The image URL of the user
    var imageUrl: String = ""
        set(value) {
            field = value
            setChangedAndNotify("imageUrl")
        }




    private fun setChangedAndNotify(field: Any)
    {
        setChanged()
        notifyObservers(field)
    }
}