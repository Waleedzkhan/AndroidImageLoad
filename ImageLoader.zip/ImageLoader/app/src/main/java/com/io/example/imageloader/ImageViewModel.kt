package com.io.example.imageloader

import android.databinding.BaseObservable
import android.databinding.Bindable
import android.view.View
import com.io.example.imageloader.BR
import com.io.example.imageloader.User
import java.util.Observable
import java.util.Observer
import java.util.Locale


class UserViewModel(private val user: User) : Observer, BaseObservable() {

    /// Register itself as the observer of Model
    init {
        user.addObserver(this)
    }

    /// Notify the UI when change event emitting from Model is received.
    override fun update(p0: Observable?, p1: Any?) {
        if (p1 is String) {
             if (p1 == "imageUrl") {
                notifyPropertyChanged(BR.imageUrl)
            }
        }
    }







    val imageUrl: String
        @Bindable get() {
            return user.imageUrl
        }



    fun onButtonClick(view: View) {

        this.user.imageUrl = "https://media.giphy.com/media/w7M8g9cTom0Du/giphy.gif"

    }

}